# Assets

Interface icons and charts are inline SVG; decorative elements use CSS. No external image assets are required. Google Fonts are optional, with local system-font fallbacks.
